﻿using System;
using System.Data.SqlClient;
using System.Web.UI.WebControls;
using System.Web.Configuration;

namespace MiniProject
{
    public static class CommonUtility
    {
        public static void LoadAccountNumbers(DropDownList ddlAccountNumberUpdate, DropDownList ddlAccountNumberDelete, DropDownList ddlAccountNumber)
        {
            string connectionString = WebConfigurationManager.ConnectionStrings["MyDbConnectionString"].ConnectionString;
            string selectSQL = "SELECT AccountNumber FROM customer";
            using (SqlConnection scon = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand(selectSQL, scon);
                try
                {
                    scon.Open();
                    SqlDataReader reader = cmd.ExecuteReader();

                    ddlAccountNumberUpdate.Items.Clear();
                    ddlAccountNumberDelete.Items.Clear();
                    ddlAccountNumber.Items.Clear();

                    while (reader.Read())
                    {
                        string AccountNumber = reader["AccountNumber"].ToString();
                        ddlAccountNumberUpdate.Items.Add(new ListItem(AccountNumber, AccountNumber));
                        ddlAccountNumberDelete.Items.Add(new ListItem(AccountNumber, AccountNumber));
                        ddlAccountNumber.Items.Add(new ListItem(AccountNumber, AccountNumber));
                    }
                    reader.Close();
                }
                catch (Exception err)
                {
                    throw new Exception("Error loading account numbers: " + err.Message);
                }
            }
        }
    }
}
