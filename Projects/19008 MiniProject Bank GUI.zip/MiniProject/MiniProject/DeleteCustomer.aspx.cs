﻿using System;
using System.Data.SqlClient;
using System.Web.Configuration;
using System.Web.UI;
using System.Web.UI.WebControls; // Add this namespace

namespace MiniProject
{
    public partial class DeleteCustomer : Page
    {
        private string connectionString = WebConfigurationManager.ConnectionStrings["MyDbConnectionString"].ConnectionString;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                LoadAccountNumbers();
            }
        }

        protected void btnDelete_Click(object sender, EventArgs e)
        {
            string deleteSQL = "DELETE FROM customer WHERE AccountNumber = @AccountNumber";
            using (SqlConnection scon = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand(deleteSQL, scon);
                cmd.Parameters.AddWithValue("@AccountNumber", ddlAccountNumberDelete.SelectedValue);

                try
                {
                    scon.Open();
                    cmd.ExecuteNonQuery();
                    Response.Write("Customer deleted successfully!");
                    LoadAccountNumbers(); // Refresh dropdowns
                }
                catch (Exception err)
                {
                    Response.Write("Error: " + err.Message);
                }
            }
        }

        private void LoadAccountNumbers()
        {
            string selectSQL = "SELECT AccountNumber FROM customer";
            using (SqlConnection scon = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand(selectSQL, scon);
                try
                {
                    scon.Open();
                    SqlDataReader reader = cmd.ExecuteReader();

                    ddlAccountNumberDelete.Items.Clear();

                    while (reader.Read())
                    {
                        string accountNumber = reader["AccountNumber"].ToString();
                        ddlAccountNumberDelete.Items.Add(new ListItem(accountNumber, accountNumber));
                    }
                    reader.Close();
                }
                catch (Exception err)
                {
                    Response.Write("Error: " + err.Message);
                }
            }
        }
    }
}
