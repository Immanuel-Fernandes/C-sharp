﻿using System;
using System.Data.SqlClient;
using System.Web.Configuration;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace MiniProject
{
    public partial class DisplayAllCustomers : Page
    {
        private string connectionString = WebConfigurationManager.ConnectionStrings["MyDbConnectionString"].ConnectionString;

        protected void btnDisplayAll_Click(object sender, EventArgs e)
        {
            string selectSQL = "SELECT * FROM customer";
            using (SqlConnection scon = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand(selectSQL, scon);
                try
                {
                    scon.Open();
                    SqlDataReader reader = cmd.ExecuteReader();
                    GridView1.DataSource = reader;
                    GridView1.DataBind();
                }
                catch (Exception err)
                {
                    Response.Write("Error: " + err.Message);
                }
            }
        }
    }
}
