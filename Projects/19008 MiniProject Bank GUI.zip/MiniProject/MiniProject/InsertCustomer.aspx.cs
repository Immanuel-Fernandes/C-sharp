﻿using System;
using System.Data.SqlClient;
using System.Web.Configuration;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace MiniProject
{
    public partial class InsertCustomer : Page
    {
        private string connectionString = WebConfigurationManager.ConnectionStrings["MyDbConnectionString"].ConnectionString;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                LoadAccountNumbers();
            }
        }

        protected void btnInsert_Click(object sender, EventArgs e)
        {
            string insertSQL = "INSERT INTO customer (AccountNumber, CustomerName, BankBalance) VALUES (@AccountNumber, @CustomerName, @BankBalance)";
            using (SqlConnection scon = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand(insertSQL, scon);
                cmd.Parameters.AddWithValue("@AccountNumber", txtAccountNumber.Text);
                cmd.Parameters.AddWithValue("@CustomerName", txtCustomerName.Text);
                cmd.Parameters.AddWithValue("@BankBalance", txtBankBalance.Text);

                try
                {
                    scon.Open();
                    cmd.ExecuteNonQuery();
                    Response.Write("Customer inserted successfully!");
                    LoadAccountNumbers(); // Refresh dropdowns
                }
                catch (Exception err)
                {
                    Response.Write("Error: " + err.Message);
                }
            }
        }

        private void LoadAccountNumbers()
        {
            string selectSQL = "SELECT AccountNumber FROM customer";
            using (SqlConnection scon = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand(selectSQL, scon);
                try
                {
                    scon.Open();
                    SqlDataReader reader = cmd.ExecuteReader();

                    // Assuming these dropdown lists are defined somewhere accessible in the master page
                    DropDownList ddlAccountNumberUpdate = (DropDownList)Master.FindControl("ddlAccountNumberUpdate");
                    DropDownList ddlAccountNumberDelete = (DropDownList)Master.FindControl("ddlAccountNumberDelete");
                    DropDownList ddlAccountNumber = (DropDownList)Master.FindControl("ddlAccountNumber");

                    if (ddlAccountNumberUpdate != null) ddlAccountNumberUpdate.Items.Clear();
                    if (ddlAccountNumberDelete != null) ddlAccountNumberDelete.Items.Clear();
                    if (ddlAccountNumber != null) ddlAccountNumber.Items.Clear();

                    while (reader.Read())
                    {
                        string accountNumber = reader["AccountNumber"].ToString();
                        if (ddlAccountNumberUpdate != null) ddlAccountNumberUpdate.Items.Add(new ListItem(accountNumber, accountNumber));
                        if (ddlAccountNumberDelete != null) ddlAccountNumberDelete.Items.Add(new ListItem(accountNumber, accountNumber));
                        if (ddlAccountNumber != null) ddlAccountNumber.Items.Add(new ListItem(accountNumber, accountNumber));
                    }
                    reader.Close();
                }
                catch (Exception err)
                {
                    Response.Write("Error: " + err.Message);
                }
            }
        }
    }
}
