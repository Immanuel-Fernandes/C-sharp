﻿using System;
using System.Data.SqlClient;
using System.Web.Configuration;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace MiniProject
{
    public partial class TransferAmt : Page
    {
        private string connectionString = WebConfigurationManager.ConnectionStrings["MyDbConnectionString"].ConnectionString;
        private string password = "19008"; // Replace with a secure method for storing passwords

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                LoadAccountNumbers();
            }
        }

        protected void btnTransfer_Click(object sender, EventArgs e)
        {
            if (txtPassword.Text != password)
            {
                lblErrorMessage.Text = "Incorrect password.";
                lblErrorMessage.Visible = true;
                lblMessage.Visible = false;
                return;
            }

            decimal amount = 0;
            if (!string.IsNullOrWhiteSpace(txtTransferAmount.Text))
            {
                amount = Convert.ToDecimal(txtTransferAmount.Text);
                if (amount > 0)
                {
                    string sourceAccountNumber = ddlSourceAccountNumber.SelectedValue;
                    string destinationAccountNumber = ddlDestinationAccountNumber.SelectedValue;

                    if (sourceAccountNumber == destinationAccountNumber)
                    {
                        lblErrorMessage.Text = "Source and destination account numbers cannot be the same.";
                        lblErrorMessage.Visible = true;
                        lblMessage.Visible = false;
                        return;
                    }

                    string checkBalanceSQL = "SELECT BankBalance FROM customer WHERE AccountNumber = @AccountNumber";
                    using (SqlConnection scon = new SqlConnection(connectionString))
                    {
                        SqlCommand cmd = new SqlCommand(checkBalanceSQL, scon);
                        cmd.Parameters.AddWithValue("@AccountNumber", sourceAccountNumber);

                        try
                        {
                            scon.Open();
                            decimal sourceBankBalance = Convert.ToDecimal(cmd.ExecuteScalar());

                            if (sourceBankBalance >= amount)
                            {
                                string updateSQL = @"
                                    BEGIN TRANSACTION;
                                    UPDATE customer SET BankBalance = BankBalance - @Amount WHERE AccountNumber = @SourceAccountNumber;
                                    UPDATE customer SET BankBalance = BankBalance + @Amount WHERE AccountNumber = @DestinationAccountNumber;
                                    COMMIT;";
                                ExecuteTransaction(updateSQL, amount, sourceAccountNumber, destinationAccountNumber, "Transfer successful!", "Failed to transfer amount. Please try again.");
                            }
                            else
                            {
                                lblErrorMessage.Text = "Insufficient Balance.";
                                lblErrorMessage.Visible = true;
                                lblMessage.Visible = false;
                            }
                        }
                        catch (Exception err)
                        {
                            lblErrorMessage.Text = "Error: " + err.Message;
                            lblErrorMessage.Visible = true;
                            lblMessage.Visible = false;
                        }
                    }
                }
                else
                {
                    lblErrorMessage.Text = "Please enter a valid transfer amount.";
                    lblErrorMessage.Visible = true;
                    lblMessage.Visible = false;
                }
            }
            else
            {
                lblErrorMessage.Text = "Please enter a valid number.";
                lblErrorMessage.Visible = true;
                lblMessage.Visible = false;
            }
        }

        private void ExecuteTransaction(string sql, decimal amount, string sourceAccountNumber, string destinationAccountNumber, string successMessage, string errorMessage)
        {
            using (SqlConnection scon = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand(sql, scon);
                cmd.Parameters.AddWithValue("@SourceAccountNumber", sourceAccountNumber);
                cmd.Parameters.AddWithValue("@DestinationAccountNumber", destinationAccountNumber);
                cmd.Parameters.AddWithValue("@Amount", amount);

                try
                {
                    scon.Open();
                    cmd.ExecuteNonQuery();
                    lblMessage.Text = successMessage;
                    lblMessage.Visible = true;
                    lblErrorMessage.Visible = false;
                    LoadAccountNumbers(); // Refresh dropdowns
                }
                catch (Exception err)
                {
                    lblErrorMessage.Text = errorMessage + " Error: " + err.Message;
                    lblErrorMessage.Visible = true;
                    lblMessage.Visible = false;
                }
            }
        }

        private void LoadAccountNumbers()
        {
            string selectSQL = "SELECT AccountNumber FROM customer";
            using (SqlConnection scon = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand(selectSQL, scon);
                try
                {
                    scon.Open();
                    SqlDataReader reader = cmd.ExecuteReader();

                    ddlSourceAccountNumber.Items.Clear();
                    ddlDestinationAccountNumber.Items.Clear();

                    while (reader.Read())
                    {
                        string accountNumber = reader["AccountNumber"].ToString();
                        ddlSourceAccountNumber.Items.Add(new ListItem(accountNumber, accountNumber));
                        ddlDestinationAccountNumber.Items.Add(new ListItem(accountNumber, accountNumber));
                    }
                    reader.Close();
                }
                catch (Exception err)
                {
                    lblErrorMessage.Text = "Error loading account numbers: " + err.Message;
                    lblErrorMessage.Visible = true;
                }
            }
        }
    }
}
