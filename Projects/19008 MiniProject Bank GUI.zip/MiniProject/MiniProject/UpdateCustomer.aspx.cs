﻿using System;
using System.Data.SqlClient;
using System.Web.Configuration;
using System.Web.UI;
using System.Web.UI.WebControls; // Add this namespace

namespace MiniProject
{
    public partial class UpdateCustomer : Page
    {
        private string connectionString = WebConfigurationManager.ConnectionStrings["MyDbConnectionString"].ConnectionString;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                LoadAccountNumbers();
            }
        }

        protected void btnUpdate_Click(object sender, EventArgs e)
        {
            string updateSQL = "UPDATE customer SET CustomerName = @CustomerName WHERE AccountNumber = @AccountNumber";
            using (SqlConnection scon = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand(updateSQL, scon);
                cmd.Parameters.AddWithValue("@AccountNumber", ddlAccountNumberUpdate.SelectedValue);
                cmd.Parameters.AddWithValue("@CustomerName", txtNewCustomerName.Text);

                try
                {
                    scon.Open();
                    cmd.ExecuteNonQuery();
                    Response.Write("Customer updated successfully!");
                }
                catch (Exception err)
                {
                    Response.Write("Error: " + err.Message);
                }
            }
        }

        private void LoadAccountNumbers()
        {
            string selectSQL = "SELECT AccountNumber FROM customer";
            using (SqlConnection scon = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand(selectSQL, scon);
                try
                {
                    scon.Open();
                    SqlDataReader reader = cmd.ExecuteReader();

                    ddlAccountNumberUpdate.Items.Clear();

                    while (reader.Read())
                    {
                        string accountNumber = reader["AccountNumber"].ToString();
                        ddlAccountNumberUpdate.Items.Add(new ListItem(accountNumber, accountNumber));
                    }
                    reader.Close();
                }
                catch (Exception err)
                {
                    Response.Write("Error: " + err.Message);
                }
            }
        }
    }
}
