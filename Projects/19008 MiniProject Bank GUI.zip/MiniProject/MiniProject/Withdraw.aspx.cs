﻿using System;
using System.Data.SqlClient;
using System.Web.Configuration;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace MiniProject
{
    public partial class Withdraw : Page
    {
        private string connectionString = WebConfigurationManager.ConnectionStrings["MyDbConnectionString"].ConnectionString;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                LoadAccountNumbers();
            }
        }

        protected void btnWithdraw_Click(object sender, EventArgs e)
        {
            decimal amount = 0;
            if (!string.IsNullOrWhiteSpace(txtAmount.Text))
            {
                amount = Convert.ToDecimal(txtAmount.Text);
                if (amount > 0)
                {
                    string checkBalanceSQL = "SELECT BankBalance FROM customer WHERE AccountNumber = @AccountNumber";
                    using (SqlConnection scon = new SqlConnection(connectionString))
                    {
                        SqlCommand cmd = new SqlCommand(checkBalanceSQL, scon);
                        cmd.Parameters.AddWithValue("@AccountNumber", ddlAccountNumber.SelectedValue);

                        try
                        {
                            scon.Open();
                            decimal bankBalance = Convert.ToDecimal(cmd.ExecuteScalar());

                            if (bankBalance >= amount)
                            {
                                string updateSQL = "UPDATE customer SET BankBalance = BankBalance - @Amount WHERE AccountNumber = @AccountNumber";
                                ExecuteTransaction(updateSQL, amount, "Withdrawal successful!", "Failed to withdraw amount. Please try again.");
                            }
                            else
                            {
                                lblErrorMessage.Text = "Insufficient Balance.";
                                lblErrorMessage.Visible = true;
                                lblMessage.Visible = false;
                            }
                        }
                        catch (Exception err)
                        {
                            lblErrorMessage.Text = "Error: " + err.Message;
                            lblErrorMessage.Visible = true;
                            lblMessage.Visible = false;
                        }
                    }
                }
                else
                {
                    lblErrorMessage.Text = "Please enter a valid withdrawal amount.";
                    lblErrorMessage.Visible = true;
                    lblMessage.Visible = false;
                }
            }
            else
            {
                lblErrorMessage.Text = "Please enter a valid number.";
                lblErrorMessage.Visible = true;
                lblMessage.Visible = false;
            }
        }

        private void ExecuteTransaction(string sql, decimal amount, string successMessage, string errorMessage)
        {
            using (SqlConnection scon = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand(sql, scon);
                cmd.Parameters.AddWithValue("@AccountNumber", ddlAccountNumber.SelectedValue);
                cmd.Parameters.AddWithValue("@Amount", amount);

                try
                {
                    scon.Open();
                    cmd.ExecuteNonQuery();
                    lblMessage.Text = successMessage;
                    lblMessage.Visible = true;
                    lblErrorMessage.Visible = false;
                    LoadAccountNumbers(); // Refresh dropdowns
                }
                catch (Exception err)
                {
                    lblErrorMessage.Text = errorMessage + " Error: " + err.Message;
                    lblErrorMessage.Visible = true;
                    lblMessage.Visible = false;
                }
            }
        }

        private void LoadAccountNumbers()
        {
            string selectSQL = "SELECT AccountNumber FROM customer";
            using (SqlConnection scon = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand(selectSQL, scon);
                try
                {
                    scon.Open();
                    SqlDataReader reader = cmd.ExecuteReader();

                    ddlAccountNumber.Items.Clear();

                    while (reader.Read())
                    {
                        string accountNumber = reader["AccountNumber"].ToString();
                        ddlAccountNumber.Items.Add(new ListItem(accountNumber, accountNumber));
                    }
                    reader.Close();
                }
                catch (Exception err)
                {
                    lblErrorMessage.Text = "Error loading account numbers: " + err.Message;
                    lblErrorMessage.Visible = true;
                }
            }
        }
    }
}
