﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Script.Serialization;

namespace Soil
{
    public partial class Checkout : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                LoadCartData();
            }
        }

        private void LoadCartData()
        {
            string cartData = Request.QueryString["products"];
            decimal totalAmount = decimal.Parse(Request.QueryString["totalAmount"] ?? "0");

            if (!string.IsNullOrEmpty(cartData))
            {
                var serializer = new JavaScriptSerializer();
                List<CartItem> cartItems = serializer.Deserialize<List<CartItem>>(cartData);

                foreach (var item in cartItems)
                {
                    cartContainer.Text += String.Format("{0} - Rs. {1}<br />", item.ProductName, item.Price);
                }
            }

            // Format and display the total amount using String.Format
            totalAmountLabel.Text = String.Format("Total Amount: Rs. {0}", totalAmount.ToString("C"));
        }


        protected void PlaceOrder_Click(object sender, EventArgs e)
        {
            Session.Remove("cart");
            Response.Redirect("ThankYou.aspx");
        }

        public class CartItem
        {
            public string ProductName { get; set; }
            public decimal Price { get; set; }
        }

        protected void ProceedForPayment_Click(object sender, EventArgs e)
        {
            string selectedPaymentMethod = ddlPaymentMethod.SelectedValue;
            Session["PaymentMethod"] = selectedPaymentMethod;
            Response.Redirect("ThankYou.aspx");
        }

    }
}
