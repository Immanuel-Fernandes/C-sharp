﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.IO;
using System.Configuration;
using System.Data;


namespace Soil
{
    public partial class ManageProducts : System.Web.UI.Page
    {

        private string connectionString = ConfigurationManager.ConnectionStrings["DefaultConnection"].ConnectionString;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                BindProductGrid();
            }
        }

        protected void btnAddProduct_Click(object sender, EventArgs e)
        {
            string productName = txtProductName.Text.Trim();
            string category = txtCategory.Text.Trim();
            string description = txtDescription.Text.Trim();
            decimal price = decimal.Parse(txtPrice.Text.Trim());
            int amount = int.Parse(txtAmount.Text.Trim());

            // Handle image upload
            string imageUrl = string.Empty;
            if (fileUploadImage.HasFile)
            {
                string fileName = Path.GetFileName(fileUploadImage.FileName);
                string uploadPath = Server.MapPath("~/images/");
                if (!Directory.Exists(uploadPath))
                {
                    Directory.CreateDirectory(uploadPath);
                }
                fileUploadImage.SaveAs(Path.Combine(uploadPath, fileName));
                imageUrl = "images/" + fileName;
            }

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                SqlCommand command = new SqlCommand(
                    "INSERT INTO Products (ProductName, ImageUrl, Price, Amount, Category, Description) VALUES (@ProductName, @ImageUrl, @Price, @Amount, @Category, @Description)",
                    connection
                );
                command.Parameters.AddWithValue("@ProductName", productName);
                command.Parameters.AddWithValue("@ImageUrl", imageUrl);
                command.Parameters.AddWithValue("@Price", price);
                command.Parameters.AddWithValue("@Amount", amount);
                command.Parameters.AddWithValue("@Category", category);
                command.Parameters.AddWithValue("@Description", description);

                command.ExecuteNonQuery();
            }

            // Refresh product grid
            BindProductGrid();
            Response.Write("<script>alert('Product added successfully!');</script>");
        }

        private void BindProductGrid()
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                SqlCommand command = new SqlCommand("SELECT * FROM Products", connection);
                SqlDataAdapter adapter = new SqlDataAdapter(command);
                DataTable dt = new DataTable();
                adapter.Fill(dt);
                gvProducts.DataSource = dt;
                gvProducts.DataBind();
            }
        }


        protected void gvProducts_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            try
            {
                // Fetch ProductId from DataKeys
                int productId = Convert.ToInt32(gvProducts.DataKeys[e.RowIndex].Value);

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    SqlCommand command = new SqlCommand("DELETE FROM Products WHERE ProductId = @ProductId", connection);
                    command.Parameters.AddWithValue("@ProductId", productId);
                    command.ExecuteNonQuery();
                }

                // Refresh the GridView
                BindProductGrid();
                Response.Write("<script>alert('Product deleted successfully!');</script>");
            }
            catch (Exception ex)
            {
                Response.Write("<script>alert('Error: {ex.Message}');</script>");
            }
        }

    }
}