﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace Soil
{
    public partial class ProductView : System.Web.UI.Page
    {
        protected string ProductName { get; set; }
        protected decimal ProductPrice { get; set; }
        protected string ProductDescription { get; set; }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                // Fetch Product ID from query string
                string productId = Request.QueryString["productID"];

                if (string.IsNullOrEmpty(productId))
                {
                    Response.Redirect("UserDashboard.aspx"); // Redirect if no product is selected
                }
                else
                {
                    // Load product details based on ProductID
                    LoadProductDetails(int.Parse(productId));
                }
            }
        }

        private void LoadProductDetails(int productId)
        {
            // Example database connection and query to get product details
            string connectionString = ConfigurationManager.ConnectionStrings["DefaultConnection"].ConnectionString;
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                string query = "SELECT ProductName, ProductPrice, Description FROM Product WHERE ProductID = @ProductID";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@ProductID", productId);

                conn.Open();
                SqlDataReader reader = cmd.ExecuteReader();

                if (reader.Read())
                {
                    ProductName = reader["ProductName"].ToString();
                    ProductPrice = (decimal)reader["ProductPrice"];
                    ProductDescription = reader["Description"].ToString();
                }
                reader.Close();
            }
        }

        protected void AddToCartButton_Click(object sender, EventArgs e)
        {
            // Logic to add product to the shopping cart
            string productId = Request.QueryString["productID"];
            AddProductToCart(int.Parse(productId));
        }

        private void AddProductToCart(int productId)
        {
            // Your logic to add the product to the user's cart
            // This could be stored in session or database depending on your cart setup.
        }
    }
}