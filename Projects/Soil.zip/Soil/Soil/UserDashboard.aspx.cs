﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Web.Script.Serialization;

namespace Soil
{
    public partial class UserDashboard : System.Web.UI.Page
    {
        private string connectionString = ConfigurationManager.ConnectionStrings["DefaultConnection"].ConnectionString;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                // Initially, load products without sorting
                LoadProducts();
            }

            // If the cart data is in the session, load it and show it
            if (Session["cart"] != null)
            {
                List<Product> cart = (List<Product>)Session["cart"];
                DisplayCart(cart);
            }

            // If POST request comes (checkout submission)
            if (Request.HttpMethod == "POST")
            {
                string jsonString;
                using (var reader = new System.IO.StreamReader(Request.InputStream))
                {
                    jsonString = reader.ReadToEnd();
                }

                var serializer = new JavaScriptSerializer();
                var checkoutData = serializer.Deserialize<CheckoutData>(jsonString);

                // Save to database
                bool isSaved = SaveCheckoutToDatabase(checkoutData);

                Response.ContentType = "application/json";
                Response.Write(new JavaScriptSerializer().Serialize(new { success = isSaved }));
                Response.End();
            }
        }

        // This method is used to load products
        private void LoadProducts()
        {
            List<Product> productList = GetProductsFromDatabase();

            foreach (var product in productList)
            {
                string cardHtml = "<div class='productCard'>";
                cardHtml += "<img src='" + product.ImageUrl + "' alt='" + product.ProductName + "' />";
                cardHtml += "<h3>" + product.ProductName + "</h3>";
                cardHtml += "<p>" + product.Category + "</p>";
                cardHtml += "<p>Price: Rs. " + product.Price + "</p>";
                cardHtml += "<button class='addToCartButton' onclick='addToCart(" + product.ProductId + ", \"" + product.ProductName + "\", " + product.Price + ")'>Add to Cart</button>";
                cardHtml += "</div>";

                // Append the HTML to the product container dynamically
                productContainer.InnerHtml += cardHtml;
            }
        }

        // This method fetches the products from the database
        private List<Product> GetProductsFromDatabase()
        {
            List<Product> productList = new List<Product>();

            // Default SQL query to fetch products
            string query = "SELECT ProductId, ProductName, Price, Category, ImageUrl FROM Products";

            // Create a connection to the database
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                // Create a command to execute the query
                SqlCommand cmd = new SqlCommand(query, conn);

                try
                {
                    conn.Open(); // Open the connection to the database

                    // Execute the command and get the data reader
                    SqlDataReader reader = cmd.ExecuteReader();

                    // Loop through the data reader and add products to the list
                    while (reader.Read())
                    {
                        Product product = new Product
                        {
                            ProductId = Convert.ToInt32(reader["ProductId"]),
                            ProductName = reader["ProductName"].ToString(),
                            Price = Convert.ToDecimal(reader["Price"]),
                            Category = reader["Category"].ToString(),
                            ImageUrl = reader["ImageUrl"].ToString()
                        };

                        productList.Add(product); // Add the product to the list
                    }

                    reader.Close(); // Close the data reader
                }
                catch (Exception ex)
                {
                    // Handle any errors that occur during the query execution
                    Response.Write("Error: " + ex.Message);
                }
            }

            return productList; // Return the list of products
        }

        // Product class to represent the product model
        public class Product
        {
            public int ProductId { get; set; }
            public string ProductName { get; set; }
            public string ImageUrl { get; set; }
            public decimal Price { get; set; }
            public string Category { get; set; }
        }

        // Function to add a product to the cart (using session storage)
        protected void AddToCart(int productId, string productName, decimal price)
        {
            List<Product> cart = new List<Product>();

            // Check if there's an existing cart in the session
            if (Session["cart"] != null)
            {
                cart = (List<Product>)Session["cart"];
            }

            // Add the product to the cart
            Product product = new Product
            {
                ProductId = productId,
                ProductName = productName,
                Price = price
            };

            cart.Add(product);
            Session["cart"] = cart; // Store the updated cart back to the session

            // Call function to display cart on the page
            DisplayCart(cart);
        }

        // Function to display the cart on the page
        private void DisplayCart(List<Product> cart)
        {
            string cartHtml = "<div class='cartItems'>";

            foreach (var item in cart)
            {
                cartHtml += "<div class='cartItem'>";
                cartHtml += "<p>" + item.ProductName + " - Rs. " + item.Price + "</p>";
                cartHtml += "</div>";
            }

            cartHtml += "</div>";

            // Add the cart HTML to the cart container
            // cartContainer.InnerHtml = cartHtml;

            Session["cartItems"] = cartHtml;
        }

        // Save the checkout information to the database
        private bool SaveCheckoutToDatabase(CheckoutData checkoutData)
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();
                    foreach (var item in checkoutData.CartData)
                    {
                        string query = "INSERT INTO Cart (ProductId, ProductName, Price, TotalAmount) VALUES (@ProductId, @ProductName, @Price, @TotalAmount)";
                        using (SqlCommand cmd = new SqlCommand(query, conn))
                        {
                            cmd.Parameters.AddWithValue("@ProductId", item.ProductId);
                            cmd.Parameters.AddWithValue("@ProductName", item.ProductName);
                            cmd.Parameters.AddWithValue("@Price", item.Price);
                            cmd.Parameters.AddWithValue("@TotalAmount", checkoutData.TotalAmount);
                            cmd.ExecuteNonQuery();
                        }
                    }
                }
                return true;
            }
            catch (Exception ex)
            {
                // Log exception
                return false;
            }
        }

        // CheckoutData model
        public class CheckoutData
        {
            public List<CartItem> CartData { get; set; }
            public double TotalAmount { get; set; }
        }

        // CartItem model
        public class CartItem
        {
            public int ProductId { get; set; }
            public string ProductName { get; set; }
            public decimal Price { get; set; }
        }
    }
}
